$(function(){
	//头部菜单特效
	$('.w .f1 .lis').mouseenter(function(){
		$('.w .f1 .dorpdown').show();
		$('.w .f1 .wrap').css({'border':'1px solid #ddd','background':'#ffffff'});
	});

	$('.w .f1 .lis').mouseleave(function(){
		$('.w .f1 .dorpdown').hide();
		$('.w .f1 .wrap').css({'border':'none','background':'none'});
	});


	$('.w .f2 .fore3').mouseenter(function(){
		$('.w .f2 .fore3 .dorpdown').show();
		$('.w .f2 .fore3 .dt').css({'border':'1px solid #ddd','background':'#ffffff'});
	});

	$('.w .f2 .fore3').mouseleave(function(){
		$('.w .f2 .fore3 .dorpdown').hide();
		$('.w .f2 .fore3 .dt').css({'border':'none','background':'none'});
	});

	$('.w .f2 .fore8').mouseenter(function(){
		$('.w .f2 .fore8 .dorpdown').show();
		$('.w .f2 .fore8 .dt').css({'border':'1px solid #ddd','background':'#ffffff'});
	});

	$('.w .f2 .fore8').mouseleave(function(){
		$('.w .f2 .fore8 .dorpdown').hide();
		$('.w .f2 .fore8 .dt').css({'border':'none','background':'none'});
	});


//购物车显示特效
	$('.navigation .dorpdown').mouseenter(function(){
		$('.navigation .dorpdown-layer').show();
		$('.navigation .dorpdown-layer').css({'right':'0','border':'1px solid #ddd','background':'#ffffff','box-shadow':'0 0 5px rgba(0,0,0,.2)'});
		$('.navigation .dorpdown').css({'background':'#fff','box-shadow':'0 0 5px rgba(0,0,0,.2)'});
		$('.navigation .dorpdown .icon').css({'background':'#fff'});
	});

	$('.navigation .dorpdown').mouseleave(function(){
		$('.navigation .dorpdown-layer').hide();
		$('.navigation .dorpdown').css({'border':'none','box-shadow':'none'});
		$('.navigation .dorpdown .icon').css({'background':'#f9f9f9'});
	});

//水果菜单栏标签页效果
	$('.container .nav .main ul.out li a').mouseenter(function(){
		$(this).addClass('active');
		$('.container .nav .main ul.out li a').not($(this)).removeClass('active');
		idx=$(this).index('.container .nav .main ul.out li a');
		$('.indexTabBoxBottom .indexTabCon').eq(idx).show();
		$('.indexTabBoxBottom .indexTabCon').not($('.indexTabBoxBottom .indexTabCon').eq(idx)).hide();
	});
	$('.container .nav .main').mouseleave(function(){
		$('.container .nav .main ul.out li a').removeClass('active');
		$('.indexTabBoxBottom .indexTabCon').eq(idx).hide();
	});


	// 轮播幻灯片设计
	$(function () {
				//手动控制轮播图
				$('.one li').eq(0).show();

				$('.two li').mouseover(function () {
		$(this).addClass('on').siblings().removeClass('on');
		var index = $(this).index();
		i = index;
		$('.one li').eq(index).stop().fadeIn(300).siblings().stop().fadeOut(300);
				})
				//自动播放
				var i = 0;
				var t = setInterval(move, 1500);
				//自动播放核心函数
				function move() {
		i++;
		if (i == 4) {
			i = 0;
		}
		$('.two li').eq(i).addClass('on').siblings().removeClass('on');
		$('.one li').eq(i).fadeIn(300).siblings().fadeOut(300);
				}

				//向右播放核心函数
				function moveL() {
		i--;
		if (i == -1) {
			i = 4;
		}
		$('.two li').eq(i).addClass('on').siblings().removeClass('on');
		$('.one li').eq(i).fadeIn(300).siblings().fadeOut(300);
				}
				$('.slider-page .left').click(function () {
		moveL();
				})
				$('.slider-p age .right').click(function () {
		move();
				})
				//鼠标移入移除
				$('.lunbo').hover(function () {
		clearInterval(t);
				}, function () {
		t = setInterval(move, 1500);
				})

})



//倒计时	
// 3700=3600+100
// 1)1小时
// 2)1分钟
// 3)40秒

hour=2;
second=hour*3600;

setInterval(function(){
	second--;
	hour2=Math.floor(second/3600);
	minute2=Math.floor((second-(hour2*3600))/60);
	second2=second-(hour2*3600)-(minute2*60);

	$('.hour').html(hour2);
	$('.minute').html(minute2);
	$('.second').html(second2);
},1000);





//早市食物图标标签左右控制

	$('.fresh .fresh-market .fresh-sells .controlRight').click(function(){
		$('.fresh .fresh-market .fresh-sells .slider .one').animate({
			'left':'-1200px'
		},500);
	});
		

	$('.fresh .fresh-market .fresh-sells .controlLeft').click(function(){
		$('.fresh .fresh-market .fresh-sells .slider .one').animate({
			'left':'0px'
		},500);
	});
});                 